from flask import Flask, render_template, request, redirect, url_for, flash
from db import list_patients_ordered_by_last_name, low_stock, staff_share, schedule_appointment, insert_patient
app = Flask(__name__)


@app.route('/')
def homepage():
    return render_template('index.html')

@app.route('/patients', methods=['GET', 'POST'])
def patients_page():
    if request.method == 'POST':
        try:
            insert_patient(
                int(request.form['iid']),
                request.form['cin'],
                request.form['full_name'],
                request.form['birth'],
                request.form['sex'],
                request.form.get('blood') or None,
                request.form.get('phone') or None
            )
            flash('Patient added successfully to the database!', 'success')
        except Exception as e:
            flash(f'Error adding patient: {str(e)}', 'error')
        return redirect(url_for('patients_page'))
    data = list_patients_ordered_by_last_name()
    return render_template('patients.html', data=data)

@app.route('/staffShare')
def staff_share_page():
    data = staff_share()
    return render_template('staff_share.html', data=data)

@app.route('/appointments', methods=['GET', 'POST'])
def sched_app_page():
    if request.method == 'POST':
        schedule_appointment(
            int(request.form['caid']),
            int(request.form['iid']),
            int(request.form['staff_id']),
            int(request.form['dep_id']),
            request.form['date'],
            request.form['time'],
            request.form['reason']
        )
        return redirect(url_for('sched_app_page'))
    return render_template('sched_app.html')

@app.route('/stock')
def low_stock_page():
    data = low_stock()
    return render_template('low_stock.html', data=data)

if __name__ == '__main__':
    app.run(debug=True)
