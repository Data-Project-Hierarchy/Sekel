import os
from dotenv import load_dotenv
import mysql.connector
from mysql.connector import errorcode

load_dotenv()

cfg = dict(
    host=os.getenv("MYSQL_HOST"),
    port=int(os.getenv("MYSQL_PORT", 3306)),
    database=os.getenv("MYSQL_DB"),
    user=os.getenv("MYSQL_USER"),
    password=os.getenv("MYSQL_PASSWORD"),
    )

def get_connection():
    return mysql.connector.connect(**cfg)

def list_patients_ordered_by_last_name(limit=20):
    sql = """
    SELECT IID, FullName
    FROM Patient
    ORDER BY SUBSTRING_INDEX(FullName, ' ',-1), FullName
    LIMIT %s
    """
    with get_connection() as cnx:
        with cnx.cursor(dictionary=True) as cur:
            cur.execute(sql, (limit,))
            return cur.fetchall()
        
def insert_patient(iid, cin, full_name, birth, sex, blood, phone):
    sql = """
    INSERT INTO Patient(IID, CIN, FullName, Birth, Sex, BloodGroup, Phone)
    VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    with get_connection() as cnx:
        try:
            with cnx.cursor(dictionary=True) as cur:
                cur.execute(sql, (iid, cin, full_name, birth, sex, blood, phone))
            cnx.commit()
        except Exception:
            cnx.rollback()  
            raise

if __name__ == "__main__":
    for row in list_patients_ordered_by_last_name():
        print(f"{row['IID']} {row['FullName']}")

def schedule_appointment(caid, iid, staff_id, dep_id, date_str, time_str, reason):
    ins_ca = """
    INSERT INTO ClinicalActivity(CAID, IID, STAFF_ID, DEP_ID, Date, Time)
    VALUES (%s, %s, %s, %s, %s, %s)
    """
    ins_appt = """
    INSERT INTO Appointment(CAID, Reason, Status)
    VALUES (%s, %s, 'Scheduled')
    """
    with get_connection() as cnx:
        try:
            with cnx.cursor(dictionary=True) as cur:
                cur.execute(ins_ca, (caid, iid, staff_id, dep_id, date_str, time_str))
                cur.execute(ins_appt, (caid, reason))
            cnx.commit()
        except Exception:
            cnx.rollback()
            raise

def low_stock():
    sql = """
    SELECT S.HID, S.MID, S.StockTimestamp, S.UnitPrice, S.Qty, S.ReorderLevel,
           M.M_Name, M.Form, M.Strength, M.ActiveIngredient, M.TherapeuticClass, M.Manufacturer
    FROM Stock S
    LEFT JOIN Medication M ON S.MID = M.MID
    WHERE S.Qty < S.ReorderLevel
    ORDER BY S.HID, S.MID;
    """
    with get_connection() as cnx:
        with cnx.cursor(dictionary=True) as cur:
            cur.execute(sql)
            return cur.fetchall()

def staff_share():
    sql = """
    SELECT H.HID, H.Name, S.staff_id, S.fullName, COUNT(CA.caid) AS staff_count, SUM(COUNT(CA.caid)) OVER(PARTITION BY H.HID) AS hospital_count, ROUND(100.0 * COUNT(CA.caid) / SUM(COUNT(CA.caid)) OVER(PARTITION BY H.HID), 2) AS staff_share_pct
    FROM Staff S, ClinicalActivity CA, Appointment A, Department D, Hospital H, Work_in W
    WHERE S.staff_id = CA.staff_id AND S.staff_id = W.staff_id AND A.caid = CA.caid AND  W.dep_id = D.dep_id AND D.HID = H.HID
    GROUP BY S.staff_id, H.HID, H.Name, S.fullName
    ORDER BY H.HID, S.fullName;
    """

    with get_connection() as cnx:
        with cnx.cursor(dictionary=True) as cur:
            cur.execute(sql)
            return cur.fetchall()
