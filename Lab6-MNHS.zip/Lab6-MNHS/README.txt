Hospital Management System

A Flask web application for managing hospital patients, appointments, staff utilization, and low stock inventory with MySQL backend.

Features :
- ✅ List patients ordered by last name
- ✅ Add new patients via web form
- ✅ Schedule appointments (ClinicalActivity + Appointment)
- ✅ View low stock medications (Stock < ReorderLevel)
- ✅ Staff share analytics per hospital (% utilization)

1. Create a dedicated database user with least privilege.
    Run the code in .\data_setting\user_set.sql in mysql

2. Set Database
    Run the code in .\data_setting\Lab.sql in mysql

3. Create a virtual environnement (Optionnal but Recommended)
    python-m venv .venv

4. Run environnement (Optionnal but Recommended)
    source .venv/bin/activate (Linux/MacOS)
    .venv\scripts\Activate.ps1 (Windows)

5. Install Python Dependencies
    pip install flask mysql-connector-python python-dotenv

6. Run the database connexion file
    py db.py

7. Run The Application
    py main.py

8. Open Browser
    https://127.0.0.1:5000

9. Routes
    '/' : homepage
    '/patients': List/Add patients
    '/appointments': Schedule appointments
    '/stock': Low stock medications
    'staffShare': Staff utilization dashboard
